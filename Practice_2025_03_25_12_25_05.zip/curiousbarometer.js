function setup() {
  createCanvas(300,300);
  strokeWeight(2);
  background(50);
}

function draw() {
  stroke(random(100), random(20), random(300));
  line(random(width), random(height), random(width), random(height));
}