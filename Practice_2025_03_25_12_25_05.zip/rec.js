function setup() {
  createCanvas(250,250);
  background(150);
  rect(75,75,100,100)
}