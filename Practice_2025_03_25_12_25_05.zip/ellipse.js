function setup() {
  createCanvas(250,250);
  background(150);
  ellipse(125,125,125,125);
}