function setup() {
  createCanvas(250,250);
  background(150);
  rect(10,10,100,100);
  scale(1,2);
  rect(120,10,100,100);
}