function setup() {
  createCanvas(250,250);
  background(150);
  translate(75,60);
  triangle(50,0,100,100,0,100);
}
