function setup() { 
  createCanvas(600, 400);
  background(255);
  stroke(5);
  noFill(); 
  strokeWeight(2);

  translate(0, height / 2);

  beginShape();

  var noiseCount = 0;
  for (var i = 0; i < width; i += 1) {
    var ranY = noise(noiseCount); 
    vertex(i, ranY * 120);
    noiseCount += 0.04; 

  }
  endShape();
}