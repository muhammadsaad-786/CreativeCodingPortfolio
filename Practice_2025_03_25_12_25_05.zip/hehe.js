function setup() {
  createCanvas(250,250);
  background(150);

  
translate(width/2 - 150, 0);
beginShape();
vertex(0,100);
bezierVertex( 0, 100, 50, 0, 100, 100);
bezierVertex(70, 70, 75, 125, 125, 75);
bezierVertex(200, 100, 250, 0, 300, 100);
vertex(300, 300);
vertex( 0, 300);
vertex( 0, 100);
endShape();
}