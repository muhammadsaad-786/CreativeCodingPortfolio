function setup() {
  createCanvas(250,250);
  background(150);
  rect(70,10,50,50)
  rotate(PI/4);
  rect(70,10,50,50);
}