var img;

function preload() {

img = loadImage("download.jpg");

}



function setup () {

createCanvas (400, 400);

background(255);

}



function draw() {

background(255);

image(img, 0, 0);

filter(INVERT);
}