var word = "Hello World"
var wholeNum = 100;
var decimalNum = 100;

function setup() {
  createCanvas(250,250);
  background(150);
  rectMode(CENTER);
  rect(width/2, height/2, decimalNum, wholeNum);
  print(word);
  ellipse(80,80,100,100);
  line(30,220,220,30);
  
  beginShape();
  vertex(0,50);
  bezierVertex(100,50,100,80,80,80);
  endShape();
  

  
}