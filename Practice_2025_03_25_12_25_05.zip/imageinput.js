var img;

function preload() {

img = loadImage("download.jpg");

}



function setup () {

createCanvas (400, 400);

background(0);

}



function draw() {

background(0);
  tint(230, 100, 0);

image(img, 0, 0, img.width, img.height);
  
noTint();
image(img, 0, img.height, img.width, img.height);

}